﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp11
{

    public partial class clock : Form
    {
        int minutes;
        int seconds;
        int hours;
        public clock()
        {
            DateTime dt = DateTime.Now;
            hours =Convert.ToInt32(dt.ToString("HH"));
            minutes = Convert.ToInt32(dt.ToString("mm"));
            seconds = Convert.ToInt32(dt.ToString("ss"));
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            seconds++;
            hours = hours % 24;
            if (seconds > 59)
            {
                seconds = 0;
                minutes += 1;
            }
            if (minutes > 59)
            {
                hours += 1;
                minutes = 0;
            }
            if ((hours / 10) < 1)
            {
                label1.Text = $"0{hours}";
            }
            else
            {
                label1.Text = $"{hours}";
            }
            if ((minutes / 10) < 1)
            {
                label3.Text = $"0{minutes}";
            }
            else
            {
                label3.Text = $"{minutes}";
            }
            if ((seconds / 10) < 1)
            {
                label5.Text = $"0{seconds}";
            }
            else
            {
                label5.Text = $"{seconds}";
            }

        }
    }
}

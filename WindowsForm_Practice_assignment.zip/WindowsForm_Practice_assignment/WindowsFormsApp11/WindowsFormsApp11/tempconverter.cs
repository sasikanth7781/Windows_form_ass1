﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp11
{
    public partial class tempconverter : Form
    {
        public tempconverter()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s = richTextBox1.Text;
            if (comboBox1.Text== "Fahrenheit")
            {
                if (s.Contains("F")||s.Contains("f"))
                {
                    label1.Text = s;
                }
                else if (s.Contains("C")||s.Contains("c"))
                {
                    double c=Convert.ToDouble(s.Trim('c', 'C'));
                    label1.Text = $"{c * 1.8}F";
                }
                else if(s.Contains("K") || s.Contains("k"))
                {
                    double k = Convert.ToDouble(s.Trim('K', 'k'));
                    label1.Text = $"{1.8 * (k - 273) + 32}F";
                }
                else
                {
                    label1.Text = "Not convertable";
                }

            }
            else if(comboBox1.Text=="Celsius"){
                if (s.Contains("F") || s.Contains("f"))
                {
                    double f = Convert.ToDouble(s.Trim('f', 'F'));
                    double c = (f - 32) / 1.8000;
                    label1.Text = $"{c}C";
                }
                else if (s.Contains("C") || s.Contains("c"))
                {
                    label1.Text =s;
                }
                else if (s.Contains("K") || s.Contains("k"))
                {
                    double k =Convert.ToDouble(s.Trim('K', 'k'));
                    label1.Text = $"{k - 273}C";
                }
                else
                {
                    label1.Text = "Not convertable";
                }

            }
            else
            {
                if (s.Contains("F") || s.Contains("f"))
                {
                    double f = Convert.ToDouble(s.Trim('f', 'F'));
                    label1.Text = $"{(f + 459.67) * 5 / 9}K";
                }
                else if (s.Contains("C") || s.Contains("c"))
                {
                    double c = Convert.ToDouble(s.Trim('c', 'C'));
                    label1.Text = $"{c+273}K";
                }
                else if (s.Contains("K") || s.Contains("k"))
                {
                    label1.Text = s;
                }
                else
                {
                    label1.Text = "Not convertable";
                }

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

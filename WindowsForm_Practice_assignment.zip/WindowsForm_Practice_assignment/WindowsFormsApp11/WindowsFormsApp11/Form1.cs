﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
namespace WindowsFormsApp11
{
    public partial class Form1 : Form
    {
        int minutes=0;
        int seconds = 0;
        int hours = 0;
        SpeechSynthesizer syn;
        public Form1()
        {
            InitializeComponent();
            syn= new SpeechSynthesizer();
            syn.Volume = 90;
            syn.Rate = 1;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            seconds++;
            if (seconds > 59)
            {
                seconds = 0;
                minutes += 1;
            }
            if (minutes > 59)
            {
                hours += 1;
                minutes = 0;
            }
            if((hours / 10) < 1)
            {
                label1.Text = $"0{hours}";
            }
            else
            {
                label1.Text = $"{hours}";
            }
            if((minutes / 10) < 1)
            {
                label2.Text = $"0{minutes}";
            }
            else
            {
                label2.Text = $"{minutes}";
            }
            if((seconds / 10)<1)
            {
                label3.Text = $"0{seconds}";
            }
            else
            {
                label3.Text = $"{seconds}";
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            syn.Speak("hello don your timer starts in a second");
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            syn.Speak("hello don your timer stopped");
            timer1.Stop();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
